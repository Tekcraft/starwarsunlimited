import json
import csv
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QFileDialog
from collections import defaultdict

# Function to process each card entry
def process_card_entry(card_id, count, is_foil):
    # Check if the card is a foil card
    if "*Foil" in card_id:
        is_foil = True
        card_id = card_id.replace("*Foil", "").strip()
    cards[card_id]["count"] += count
    if is_foil:
        cards[card_id]["is_foil"] = True

# Initialize a dictionary to hold the card counts and foil status
cards = defaultdict(lambda: {"count": 0, "is_foil": False})

# Load the JSON data from the uploaded file
app = QApplication([])
file_path, _ = QFileDialog.getOpenFileName(None, "Select JSON file", "", "JSON files (*.json)")
if not file_path:
    print("No file selected. Exiting.")
    exit()

with open(file_path, 'r') as file:
    data = json.load(file)

# Extract cards from the deck
for card in data.get('deck', []):
    card_id = card.get('id', '')
    count = card.get('count', 0)
    process_card_entry(card_id, count, "*Foil" in card_id)


# Ask user where to save the CSV file
save_path, _ = QFileDialog.getSaveFileName(None, "Save CSV file", "", "CSV files (*.csv)")
if not save_path:
    print("No save location selected. Exiting.")
    exit()

# Create CSV file
with open(save_path, mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(["Set", "CardNumber", "Count", "IsFoil"])

    for card_id, info in cards.items():
        set_code, card_number = card_id.split("_")
        writer.writerow([set_code, card_number, info["count"], info["is_foil"]])

print("CSV file saved successfully at:", save_path)